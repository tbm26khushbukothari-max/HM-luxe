export function rupee(amount: number): string {
  return `₹${amount.toLocaleString("en-IN")}`;
}
