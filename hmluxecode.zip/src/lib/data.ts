export const principal = {
  name: "Mr. Malhotra",
  initials: "VM",
  address: "Amrita Shergill Marg · New Delhi",
};

export const manager = {
  name: "Aarti Sethi",
  initials: "AS",
  tenure: "14 months",
  since: "March 2024",
  standby: { name: "Priya Nair", initials: "P" },
};

export const today = {
  staffIn: "4/4",
  tasks: "6/8",
  budgetUsedPct: 69,
};

export const staff = [
  { role: "Cook", name: "Ramesh Yadav", initials: "R", status: "In · 7:10", present: true },
  { role: "Housekeeper", name: "Sunita Devi", initials: "S", status: "In · 8:05", present: true },
  { role: "Driver", name: "Iqbal Khan", initials: "I", status: "In · 8:30", present: true },
  { role: "Gardener · part-time", name: "Mahesh", initials: "M", status: "Mon & Thu", present: false },
];

export const vendors = [
  { label: "Dairy — daily delivery", status: "Done · 6:40", pending: false },
  { label: "Laundry — weekly pickup", status: "Collected", pending: false },
  { label: "AC annual service", status: "Scheduled · Fri", pending: true },
  { label: "Florist — Sat arrangement", status: "Confirmed", pending: true },
];

export const ledger = {
  month: "November",
  spent: 124300,
  budget: 180000,
  categories: [
    { name: "Staff wages", amt: 68000, pct: 100 },
    { name: "Groceries & kitchen", amt: 31400, pct: 46 },
    { name: "Utilities", amt: 12900, pct: 19 },
    { name: "Maintenance & repair", amt: 8600, pct: 13 },
    { name: "Household & misc", amt: 3400, pct: 5 },
  ],
  entries: [
    { name: "Organic grocery run", meta: "Approved · today, 10:12", amt: 4210 },
    { name: "AC annual service — advance", meta: "Scheduled · Fri", amt: 6500 },
    { name: "Salary advance — Sunita", meta: "Approved · Wed", amt: 2000 },
  ],
};

export const membership = {
  placement: 75000,
  monthly: 25000,
  managerSalary: 55000,
  includes: [
    "A dedicated, vetted home manager",
    "24–48 hour continuity cover, guaranteed",
    "Insurance & bonding on your manager",
    "The operating-layer app — staff, ledger, pantry",
    "Monthly budget review, quarterly service review",
  ],
};

export const pantry = {
  reorder: [
    { name: "Coffee — single origin" },
    { name: "Olive oil — 2L" },
  ],
  inStock: [
    { name: "Basmati rice" },
    { name: "Atta — 10kg" },
    { name: "Tea — first flush" },
  ],
};

export const tasks = {
  done: [
    { name: "Morning staff briefing" },
    { name: "Grocery run & ledger entry" },
    { name: "Confirm Fri AC service" },
  ],
  open: [
    { name: "Saturday dinner — 8 guests", status: "In progress" },
    { name: "Florist & table setting", status: "Open" },
  ],
};
