import Card from "@/components/ui/Card";
import Eyebrow from "@/components/ui/Eyebrow";
import Meter from "@/components/ui/Meter";
import { ledger } from "@/lib/data";
import { rupee } from "@/lib/format";

export default function Ledger() {
  return (
    <div className="flex flex-col gap-6 pt-2">
      <Eyebrow>Home ledger · {ledger.month}</Eyebrow>

      <Card className="flex flex-col items-center py-8 text-center">
        <p className="font-display text-[38px] font-semibold leading-none text-ink">
          {rupee(ledger.spent)}
        </p>
        <p className="mt-2 font-body text-[13px] text-muted">
          of {rupee(ledger.budget)} monthly budget
        </p>
        <Meter pct={(ledger.spent / ledger.budget) * 100} className="mt-5 h-[5px]" />
        <p className="mt-4 flex items-center gap-1.5 font-body text-[13px] text-body">
          <span className="h-[6px] w-[6px] rounded-full bg-sage" aria-hidden="true" />
          On track · 11 days remaining
        </p>
      </Card>

      <div>
        <Eyebrow className="mb-3">Where it went</Eyebrow>
        <Card className="flex flex-col gap-4">
          {ledger.categories.map((cat) => (
            <div key={cat.name}>
              <div className="mb-1.5 flex items-baseline justify-between">
                <span className="font-body text-[13.5px] text-body">{cat.name}</span>
                <span className="font-display text-[16px] font-semibold text-ink">
                  {rupee(cat.amt)}
                </span>
              </div>
              <Meter pct={cat.pct} />
            </div>
          ))}
        </Card>
      </div>

      <div>
        <Eyebrow className="mb-3">Recent entries</Eyebrow>
        <Card className="p-0">
          <ul>
            {ledger.entries.map((entry, i) => (
              <li
                key={entry.name}
                className={`flex items-center gap-3.5 p-4 ${
                  i !== ledger.entries.length - 1
                    ? "border-b border-[rgba(239,233,220,0.11)]"
                    : ""
                }`}
              >
                <span
                  className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-[rgba(194,168,120,0.24)] bg-panel2 font-display text-[15px] text-brass"
                  aria-hidden="true"
                >
                  ₹
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate font-body text-[14px] font-semibold text-ink">
                    {entry.name}
                  </p>
                  <p className="mt-0.5 font-body text-[12px] text-muted">{entry.meta}</p>
                </div>
                <span className="whitespace-nowrap font-display text-[16px] font-semibold text-ink">
                  {rupee(entry.amt)}
                </span>
              </li>
            ))}
          </ul>
        </Card>
      </div>

      <p className="px-1 font-body text-[12px] leading-relaxed text-muted">
        Every rupee logged by Aarti, approved by you. Excludes HM Luxe fees.
      </p>
    </div>
  );
}
