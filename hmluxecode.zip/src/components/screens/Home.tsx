"use client";

import { ShieldCheck, ChevronRight, Package, ListChecks, Users, BookText } from "lucide-react";
import Avatar from "@/components/ui/Avatar";
import Card from "@/components/ui/Card";
import Chip from "@/components/ui/Chip";
import Eyebrow from "@/components/ui/Eyebrow";
import Meter from "@/components/ui/Meter";
import GhostButton from "@/components/ui/GhostButton";
import { principal, manager, today } from "@/lib/data";
import type { SheetName, Tab } from "@/components/PhoneShell";

export default function Home({
  onOpenSheet,
  onOpenContinuity,
  onNavigate,
}: {
  onOpenSheet: (sheet: SheetName) => void;
  onOpenContinuity: () => void;
  onNavigate: (tab: Tab) => void;
}) {
  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between pt-2">
        <div className="flex items-baseline gap-2">
          <span className="font-display text-[22px] font-semibold leading-none text-ink">HM</span>
          <span className="font-body text-[11px] font-semibold uppercase tracking-[0.22em] text-brass">
            Luxe
          </span>
        </div>
        <Avatar initials={principal.initials} size="sm" />
      </div>

      <div>
        <h1 className="font-display text-[33px] font-semibold leading-tight text-ink">
          Good evening, {principal.name}.
        </h1>
        <p className="mt-1 font-body text-[14px] text-muted">{principal.address}</p>
      </div>

      <Card>
        <div className="flex items-center gap-4">
          <Avatar initials={manager.initials} size="lg" ring />
          <div>
            <p className="font-display text-[20px] font-semibold text-ink">{manager.name}</p>
            <p className="mt-0.5 font-body text-[13px] text-muted">
              Running your home · {manager.tenure}
            </p>
          </div>
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          <Chip dot="sage">On duty</Chip>
          <Chip>Vetted</Chip>
          <Chip>Insured</Chip>
        </div>

        <div className="my-5 h-px bg-[rgba(194,168,120,0.24)]" aria-hidden="true" />

        <div className="flex items-start gap-3">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-[rgba(194,168,120,0.24)] bg-panel2">
            <ShieldCheck size={18} strokeWidth={1.4} className="text-brass" />
          </div>
          <div className="flex-1">
            <Eyebrow>Continuity assured</Eyebrow>
            <p className="mt-1.5 font-body text-[13px] leading-relaxed text-body">
              Priya stands by. If Aarti is ever away, cover arrives within 24
              hours — guaranteed.
            </p>
            <GhostButton className="mt-3" onClick={onOpenContinuity}>
              Request cover
            </GhostButton>
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-3 gap-3">
        <div className="rounded-card border border-[rgba(239,233,220,0.11)] bg-panel p-4">
          <p className="font-display text-[19px] font-semibold text-ink">{today.staffIn}</p>
          <p className="mt-1 font-body text-[11px] text-muted">Staff in</p>
        </div>
        <div className="rounded-card border border-[rgba(239,233,220,0.11)] bg-panel p-4">
          <p className="font-display text-[19px] font-semibold text-ink">{today.tasks}</p>
          <p className="mt-1 font-body text-[11px] text-muted">Tasks done</p>
          <Meter pct={75} className="mt-2" />
        </div>
        <div className="rounded-card border border-[rgba(239,233,220,0.11)] bg-panel p-4">
          <p className="font-display text-[19px] font-semibold text-ink">
            {today.budgetUsedPct}%
          </p>
          <p className="mt-1 font-body text-[11px] text-muted">Budget used</p>
          <Meter pct={today.budgetUsedPct} className="mt-2" />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <button
          type="button"
          onClick={() => onNavigate("household")}
          className="flex flex-col items-start gap-3 rounded-card border border-[rgba(239,233,220,0.11)] bg-panel p-4 text-left transition-transform active:scale-[0.98] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brass"
        >
          <Users size={20} strokeWidth={1.4} className="text-brass" />
          <div>
            <p className="font-body text-[14px] font-semibold text-ink">Household</p>
            <p className="mt-0.5 font-body text-[12px] text-muted">4 staff · 4 vendors</p>
          </div>
        </button>
        <button
          type="button"
          onClick={() => onNavigate("ledger")}
          className="flex flex-col items-start gap-3 rounded-card border border-[rgba(239,233,220,0.11)] bg-panel p-4 text-left transition-transform active:scale-[0.98] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brass"
        >
          <BookText size={20} strokeWidth={1.4} className="text-brass" />
          <div>
            <p className="font-body text-[14px] font-semibold text-ink">Ledger</p>
            <p className="mt-0.5 font-body text-[12px] text-muted">69% of budget used</p>
          </div>
        </button>
        <button
          type="button"
          onClick={() => onOpenSheet("pantry")}
          className="flex flex-col items-start gap-3 rounded-card border border-[rgba(239,233,220,0.11)] bg-panel p-4 text-left transition-transform active:scale-[0.98] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brass"
        >
          <Package size={20} strokeWidth={1.4} className="text-brass" />
          <div>
            <p className="font-body text-[14px] font-semibold text-ink">Pantry</p>
            <p className="mt-0.5 font-body text-[12px] text-muted">2 items to reorder</p>
          </div>
        </button>
        <button
          type="button"
          onClick={() => onOpenSheet("tasks")}
          className="flex flex-col items-start gap-3 rounded-card border border-[rgba(239,233,220,0.11)] bg-panel p-4 text-left transition-transform active:scale-[0.98] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brass"
        >
          <ListChecks size={20} strokeWidth={1.4} className="text-brass" />
          <div>
            <p className="font-body text-[14px] font-semibold text-ink">Tasks</p>
            <p className="mt-0.5 font-body text-[12px] text-muted">2 open today</p>
          </div>
        </button>
      </div>

      <button
        type="button"
        onClick={() => onOpenSheet("membership")}
        className="flex items-center justify-between rounded-card border border-dashed border-[rgba(194,168,120,0.4)] bg-transparent p-4 text-left transition-transform active:scale-[0.98] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brass"
      >
        <div>
          <p className="font-body text-[14px] font-semibold text-ink">HM Luxe Membership</p>
          <p className="mt-0.5 font-body text-[12px] text-muted">
            Placement · continuity · oversight
          </p>
        </div>
        <ChevronRight size={18} strokeWidth={1.4} className="text-brass" aria-hidden="true" />
      </button>
    </div>
  );
}
