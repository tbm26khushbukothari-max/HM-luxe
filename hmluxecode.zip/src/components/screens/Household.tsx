import Avatar from "@/components/ui/Avatar";
import Card from "@/components/ui/Card";
import Eyebrow from "@/components/ui/Eyebrow";
import { staff, vendors } from "@/lib/data";

export default function Household() {
  return (
    <div className="flex flex-col gap-6 pt-2">
      <div>
        <h1 className="font-display text-[27px] font-semibold leading-tight text-ink">
          The people who keep it running.
        </h1>
        <p className="mt-1 font-body text-[13px] text-muted">
          Coordinated by Aarti · attendance live
        </p>
      </div>

      <Card className="p-0">
        <ul>
          {staff.map((member, i) => (
            <li
              key={member.name}
              className={`flex items-center gap-3.5 p-4 ${
                i !== staff.length - 1 ? "border-b border-[rgba(239,233,220,0.11)]" : ""
              }`}
            >
              <Avatar initials={member.initials} />
              <div className="min-w-0 flex-1">
                <Eyebrow>{member.role}</Eyebrow>
                <p className="mt-0.5 font-body text-[14.5px] font-semibold text-ink">
                  {member.name}
                </p>
              </div>
              <div className="flex items-center gap-1.5 whitespace-nowrap">
                {member.present && (
                  <span className="h-[6px] w-[6px] rounded-full bg-sage" aria-hidden="true" />
                )}
                <span className="font-body text-[12px] text-muted">{member.status}</span>
              </div>
            </li>
          ))}
        </ul>
      </Card>

      <div>
        <Eyebrow className="mb-3">Vendors & services</Eyebrow>
        <Card className="p-0">
          <ul>
            {vendors.map((vendor, i) => (
              <li
                key={vendor.label}
                className={`flex items-center justify-between gap-3 p-4 ${
                  i !== vendors.length - 1 ? "border-b border-[rgba(239,233,220,0.11)]" : ""
                }`}
              >
                <span className="font-body text-[14px] text-body">{vendor.label}</span>
                <span className="flex items-center gap-1.5 whitespace-nowrap">
                  <span
                    className={`h-[6px] w-[6px] rounded-full ${
                      vendor.pending ? "bg-clay" : "bg-sage"
                    }`}
                    aria-hidden="true"
                  />
                  <span className="font-body text-[12px] text-muted">{vendor.status}</span>
                </span>
              </li>
            ))}
          </ul>
        </Card>
      </div>

      <p className="px-1 font-body text-[12px] leading-relaxed text-muted">
        Rosters, attendance & pay handled by Aarti — always visible to you.
      </p>
    </div>
  );
}
