"use client";

import { Check, Star } from "lucide-react";
import Avatar from "@/components/ui/Avatar";
import Card from "@/components/ui/Card";
import Chip from "@/components/ui/Chip";
import Eyebrow from "@/components/ui/Eyebrow";
import GhostButton from "@/components/ui/GhostButton";
import { manager } from "@/lib/data";

const badges = [
  "Police-verified",
  "References checked",
  "Insured & bonded",
  "HM Academy certified",
];

const runs = [
  "Household budgeting & the monthly ledger",
  "Staff hiring, rosters & vendor management",
  "Inventory, procurement & reordering",
  "Guest, travel & event hosting",
];

export default function Manager({ onOpenContinuity }: { onOpenContinuity: () => void }) {
  return (
    <div className="flex flex-col gap-6 pt-2">
      <div className="flex flex-col items-center pt-4 text-center">
        <Avatar initials={manager.initials} size="lg" ring />
        <p className="mt-4 font-display text-[24px] font-semibold text-ink">{manager.name}</p>
        <p className="mt-1 font-body text-[13px] text-muted">
          With your home since {manager.since}
        </p>
        <div className="mt-3 flex flex-wrap justify-center gap-2">
          <Chip dot="sage">On duty</Chip>
          <Chip>B.Com · Hotel Mgmt dip.</Chip>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {badges.map((label) => (
          <div
            key={label}
            className="flex items-center gap-2.5 rounded-card border border-[rgba(239,233,220,0.11)] bg-panel p-3.5"
          >
            <Check size={16} strokeWidth={1.6} className="shrink-0 text-brass" aria-hidden="true" />
            <span className="font-body text-[12.5px] text-body">{label}</span>
          </div>
        ))}
      </div>

      <Card>
        <Eyebrow>What Aarti runs</Eyebrow>
        <ul className="mt-3 flex flex-col">
          {runs.map((line, i) => (
            <li
              key={line}
              className={`py-3 font-body text-[14px] text-body ${
                i !== runs.length - 1 ? "border-b border-[rgba(239,233,220,0.11)]" : ""
              }`}
            >
              {line}
            </li>
          ))}
        </ul>
      </Card>

      <div className="rounded-card border border-[rgba(194,168,120,0.24)] bg-gradient-to-b from-panel2 to-panel p-5">
        <Eyebrow>Your standby manager</Eyebrow>
        <p className="mt-2 font-display text-[19px] font-semibold text-ink">
          {manager.standby.name} steps in — within 24–48 hours.
        </p>
        <p className="mt-2 font-body text-[13px] leading-relaxed text-body">
          She already holds your home&rsquo;s standing notes, so nothing is
          explained from scratch when it matters.
        </p>
        <GhostButton className="mt-4" onClick={onOpenContinuity}>
          Meet your standby
        </GhostButton>
      </div>

      <div className="px-1 text-center">
        <div className="flex justify-center gap-1" aria-hidden="true">
          {Array.from({ length: 5 }).map((_, i) => (
            <Star key={i} size={13} strokeWidth={1.4} className="fill-brass text-brass" />
          ))}
        </div>
        <p className="mt-3 font-display text-[17px] italic leading-relaxed text-ink">
          &ldquo;Discreet, exact, unflappable. I stopped thinking about the
          house.&rdquo;
        </p>
        <p className="mt-2 font-body text-[11px] uppercase tracking-[0.14em] text-muted">
          Your private note · Mar 2025
        </p>
      </div>
    </div>
  );
}
