"use client";

import { Home, UserRound, Users, BookText } from "lucide-react";
import type { Tab } from "@/components/PhoneShell";

const TABS: { id: Tab; label: string; Icon: typeof Home }[] = [
  { id: "home", label: "Home", Icon: Home },
  { id: "manager", label: "Manager", Icon: UserRound },
  { id: "household", label: "Household", Icon: Users },
  { id: "ledger", label: "Ledger", Icon: BookText },
];

export default function TabBar({
  active,
  onChange,
}: {
  active: Tab;
  onChange: (tab: Tab) => void;
}) {
  return (
    <nav
      className="flex items-stretch border-t border-[rgba(239,233,220,0.11)] bg-bg px-2 pb-[max(10px,env(safe-area-inset-bottom))] pt-2"
      aria-label="Primary"
    >
      {TABS.map(({ id, label, Icon }) => {
        const isActive = active === id;
        return (
          <button
            key={id}
            type="button"
            onClick={() => onChange(id)}
            aria-current={isActive ? "page" : undefined}
            className="flex flex-1 flex-col items-center gap-1 rounded-[12px] py-1.5 transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brass"
          >
            <Icon
              size={20}
              strokeWidth={1.4}
              className={isActive ? "text-brass" : "text-muted"}
            />
            <span
              className={`font-body text-[10px] font-semibold uppercase tracking-[0.14em] ${
                isActive ? "text-brass" : "text-muted"
              }`}
            >
              {label}
            </span>
          </button>
        );
      })}
    </nav>
  );
}
