"use client";

import { useState } from "react";
import TabBar from "@/components/TabBar";
import Sheet from "@/components/Sheet";
import ContinuityModal from "@/components/ContinuityModal";
import Home from "@/components/screens/Home";
import Manager from "@/components/screens/Manager";
import Household from "@/components/screens/Household";
import Ledger from "@/components/screens/Ledger";
import MembershipSheet from "@/components/sheets/Membership";
import PantrySheet from "@/components/sheets/Pantry";
import TasksSheet from "@/components/sheets/Tasks";

export type Tab = "home" | "manager" | "household" | "ledger";
export type SheetName = "membership" | "pantry" | "tasks" | null;

export default function PhoneShell() {
  const [activeTab, setActiveTab] = useState<Tab>("home");
  const [activeSheet, setActiveSheet] = useState<SheetName>(null);
  const [continuityOpen, setContinuityOpen] = useState(false);

  const openSheet = (sheet: SheetName) => setActiveSheet(sheet);
  const closeSheet = () => setActiveSheet(null);
  const openContinuity = () => setContinuityOpen(true);
  const closeContinuity = () => setContinuityOpen(false);

  return (
    <div className="relative mx-auto flex h-[100dvh] max-h-[874px] w-full max-w-[404px] flex-col overflow-hidden border-[rgba(194,168,120,0.24)] bg-bg text-ink min-[480px]:h-[874px] min-[480px]:rounded-phone min-[480px]:border min-[480px]:shadow-[0_40px_80px_rgba(0,0,0,0.45)]">
      <div
        className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-brass opacity-[0.08] blur-3xl"
        aria-hidden="true"
      />

      <div className="relative z-10 flex items-center justify-between px-6 pb-1 pt-4 font-body text-[13px] text-ink">
        <span>9:41</span>
        <div className="flex items-center gap-1" aria-hidden="true">
          <span className="h-1 w-1 rounded-full bg-ink opacity-40" />
          <span className="h-1 w-1 rounded-full bg-ink opacity-40" />
          <span className="h-1 w-1 rounded-full bg-ink opacity-40" />
        </div>
      </div>

      <main className="relative z-10 flex-1 overflow-y-auto px-5 pb-8 pt-2">
        <div key={activeTab} className="animate-riseIn motion-reduce:animate-none">
          {activeTab === "home" && (
            <Home
              onOpenSheet={openSheet}
              onOpenContinuity={openContinuity}
              onNavigate={setActiveTab}
            />
          )}
          {activeTab === "manager" && <Manager onOpenContinuity={openContinuity} />}
          {activeTab === "household" && <Household />}
          {activeTab === "ledger" && <Ledger />}
        </div>
      </main>

      <div className="relative z-10">
        <TabBar active={activeTab} onChange={setActiveTab} />
      </div>

      <Sheet open={activeSheet === "membership"} onClose={closeSheet} title="HM Luxe Membership">
        <MembershipSheet />
      </Sheet>
      <Sheet open={activeSheet === "pantry"} onClose={closeSheet} title="Pantry">
        <PantrySheet />
      </Sheet>
      <Sheet open={activeSheet === "tasks"} onClose={closeSheet} title="Tasks">
        <TasksSheet />
      </Sheet>

      <ContinuityModal open={continuityOpen} onClose={closeContinuity} />
    </div>
  );
}
