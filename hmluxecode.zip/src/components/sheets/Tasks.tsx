import { tasks } from "@/lib/data";

export default function Tasks() {
  return (
    <div className="flex flex-col gap-6">
      <p className="-mt-2 font-body text-[13px] text-muted">6 done · 2 open.</p>

      <div>
        <p className="mb-3 font-body text-[11px] font-semibold uppercase tracking-[0.22em] text-brass">
          Done
        </p>
        <ul className="flex flex-col gap-2.5">
          {tasks.done.map((item) => (
            <li
              key={item.name}
              className="flex items-center justify-between rounded-card border border-[rgba(239,233,220,0.11)] bg-panel2 px-4 py-3.5"
            >
              <span className="font-body text-[14px] text-ink">{item.name}</span>
              <span className="flex items-center gap-1.5 font-body text-[12px] text-sage">
                <span className="h-[6px] w-[6px] rounded-full bg-sage" aria-hidden="true" />
                Done
              </span>
            </li>
          ))}
        </ul>
      </div>

      <div>
        <p className="mb-3 font-body text-[11px] font-semibold uppercase tracking-[0.22em] text-brass">
          Open
        </p>
        <ul className="flex flex-col gap-2.5">
          {tasks.open.map((item) => (
            <li
              key={item.name}
              className="flex items-center justify-between rounded-card border border-[rgba(239,233,220,0.11)] bg-panel2 px-4 py-3.5"
            >
              <span className="font-body text-[14px] text-ink">{item.name}</span>
              <span className="flex items-center gap-1.5 font-body text-[12px] text-clay">
                <span className="h-[6px] w-[6px] rounded-full bg-clay" aria-hidden="true" />
                {item.status}
              </span>
            </li>
          ))}
        </ul>
      </div>

      <p className="font-body text-[11.5px] leading-relaxed text-muted">
        You see what&rsquo;s handled without having to ask. That&rsquo;s the
        point.
      </p>
    </div>
  );
}
