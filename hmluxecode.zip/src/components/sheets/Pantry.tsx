import { pantry } from "@/lib/data";

export default function Pantry() {
  return (
    <div className="flex flex-col gap-6">
      <div>
        <p className="mb-3 font-body text-[11px] font-semibold uppercase tracking-[0.22em] text-brass">
          Reorder
        </p>
        <ul className="flex flex-col gap-2.5">
          {pantry.reorder.map((item) => (
            <li
              key={item.name}
              className="flex items-center justify-between rounded-card border border-[rgba(239,233,220,0.11)] bg-panel2 px-4 py-3.5"
            >
              <span className="font-body text-[14px] text-ink">{item.name}</span>
              <span className="flex items-center gap-1.5 font-body text-[12px] text-clay">
                <span className="h-[6px] w-[6px] rounded-full bg-clay" aria-hidden="true" />
                Reorder
              </span>
            </li>
          ))}
        </ul>
      </div>

      <div>
        <p className="mb-3 font-body text-[11px] font-semibold uppercase tracking-[0.22em] text-brass">
          In stock
        </p>
        <ul className="flex flex-col gap-2.5">
          {pantry.inStock.map((item) => (
            <li
              key={item.name}
              className="flex items-center justify-between rounded-card border border-[rgba(239,233,220,0.11)] bg-panel2 px-4 py-3.5"
            >
              <span className="font-body text-[14px] text-ink">{item.name}</span>
              <span className="flex items-center gap-1.5 font-body text-[12px] text-sage">
                <span className="h-[6px] w-[6px] rounded-full bg-sage" aria-hidden="true" />
                In stock
              </span>
            </li>
          ))}
        </ul>
      </div>

      <p className="font-body text-[11.5px] leading-relaxed text-muted">
        Reorders are placed by Aarti against your approved vendors and logged
        to the ledger.
      </p>
    </div>
  );
}
