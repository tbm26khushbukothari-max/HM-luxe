import { Check } from "lucide-react";
import { membership } from "@/lib/data";
import { rupee } from "@/lib/format";

const lines = [
  {
    label: "Placement",
    cadence: "one time",
    amount: `${rupee(membership.placement)}`,
    detail:
      "We source, vet, and place your manager. Free replacement if the fit isn't right within 90 days.",
  },
  {
    label: "Membership",
    cadence: "monthly",
    amount: `${rupee(membership.monthly)}`,
    detail:
      "The continuity guarantee, insurance, the app, and monthly budget oversight.",
  },
  {
    label: "Manager's salary",
    cadence: "monthly",
    amount: `from ${rupee(membership.managerSalary)}`,
    detail: "Paid to Aarti in full, billed at cost. You always see the real number.",
  },
];

export default function Membership() {
  return (
    <div className="flex flex-col gap-6">
      <p className="-mt-2 font-body text-[13px] text-muted">
        Transparent, all-in. No agency mark-up on your staff.
      </p>

      <div className="flex flex-col gap-4">
        {lines.map((line) => (
          <div
            key={line.label}
            className="rounded-card border border-[rgba(239,233,220,0.11)] bg-panel2 p-4"
          >
            <div className="flex items-baseline justify-between gap-3">
              <div>
                <p className="font-body text-[14px] font-semibold text-ink">{line.label}</p>
                <p className="font-body text-[11px] uppercase tracking-[0.14em] text-muted">
                  {line.cadence}
                </p>
              </div>
              <p className="whitespace-nowrap font-display text-[19px] font-semibold text-brass">
                {line.amount}
              </p>
            </div>
            <p className="mt-2.5 font-body text-[13px] leading-relaxed text-body">
              {line.detail}
            </p>
          </div>
        ))}
      </div>

      <div className="rounded-card border border-[rgba(194,168,120,0.24)] bg-panel2 p-4">
        <p className="font-body text-[11px] font-semibold uppercase tracking-[0.22em] text-brass">
          Every membership includes
        </p>
        <ul className="mt-3 flex flex-col gap-2.5">
          {membership.includes.map((item) => (
            <li key={item} className="flex items-start gap-2.5">
              <Check size={16} strokeWidth={1.6} className="mt-0.5 shrink-0 text-brass" aria-hidden="true" />
              <span className="font-body text-[13.5px] text-body">{item}</span>
            </li>
          ))}
        </ul>
      </div>

      <p className="font-body text-[11.5px] leading-relaxed text-muted">
        Underlying household staff and expenses are billed at actuals and
        managed within your budget. HM Luxe never marks them up.
      </p>
    </div>
  );
}
