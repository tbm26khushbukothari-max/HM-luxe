"use client";

import { ShieldCheck } from "lucide-react";
import { useState } from "react";
import Modal from "@/components/Modal";
import Avatar from "@/components/ui/Avatar";
import GhostButton from "@/components/ui/GhostButton";
import Eyebrow from "@/components/ui/Eyebrow";
import { manager } from "@/lib/data";

export default function ContinuityModal({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  const [requested, setRequested] = useState(false);

  const handleClose = () => {
    onClose();
    window.setTimeout(() => setRequested(false), 300);
  };

  return (
    <Modal open={open} onClose={handleClose} label="Continuity cover">
      <div className="flex flex-col items-center text-center">
        <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-full border border-[rgba(194,168,120,0.24)] bg-panel2">
          <ShieldCheck size={26} strokeWidth={1.4} className="text-brass" />
        </div>

        {!requested ? (
          <>
            <Eyebrow className="mb-2">Cover, on standby</Eyebrow>
            <p className="mb-5 font-body text-[14px] leading-relaxed text-body">
              {manager.standby.name} already knows your home&rsquo;s standing
              notes. If {manager.name.split(" ")[0]} is ever away, she steps in
              within 24 hours.
            </p>
            <div className="mb-6 flex w-full items-center gap-3 rounded-card border border-[rgba(239,233,220,0.11)] bg-panel2 px-4 py-3 text-left">
              <Avatar initials={manager.standby.initials} size="sm" />
              <div>
                <p className="font-display text-[16px] font-semibold text-ink">
                  {manager.standby.name}
                </p>
                <p className="font-body text-[12px] text-muted">
                  Available within 24 hours
                </p>
              </div>
            </div>
            <div className="flex w-full flex-col gap-3">
              <GhostButton
                variant="solid"
                className="w-full"
                onClick={() => setRequested(true)}
              >
                Request Priya
              </GhostButton>
              <button
                type="button"
                onClick={handleClose}
                className="font-body text-[13px] font-semibold text-muted focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brass"
              >
                Not now
              </button>
            </div>
          </>
        ) : (
          <>
            <Eyebrow className="mb-2">Cover requested</Eyebrow>
            <p className="mb-6 font-body text-[14px] leading-relaxed text-body">
              {manager.standby.name} will confirm within the hour.
              You&rsquo;ll get a note the moment she&rsquo;s locked in. Nothing
              on your end changes.
            </p>
            <GhostButton variant="sage" className="w-full" onClick={handleClose}>
              Done
            </GhostButton>
          </>
        )}
      </div>
    </Modal>
  );
}
