export default function Avatar({
  initials,
  size = "md",
  ring = false,
}: {
  initials: string;
  size?: "sm" | "md" | "lg";
  ring?: boolean;
}) {
  const sizeClasses =
    size === "lg" ? "h-20 w-20 text-2xl" : size === "sm" ? "h-9 w-9 text-xs" : "h-12 w-12 text-sm";

  return (
    <div
      className={`flex ${sizeClasses} shrink-0 items-center justify-center rounded-full bg-panel2 font-display font-semibold text-ink ${
        ring ? "ring-1 ring-brass ring-offset-2 ring-offset-bg" : "border border-[rgba(239,233,220,0.11)]"
      }`}
      aria-hidden="true"
    >
      {initials}
    </div>
  );
}
