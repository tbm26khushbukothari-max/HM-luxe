import { ReactNode } from "react";

export default function Eyebrow({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <p
      className={`font-body text-[11px] font-semibold uppercase tracking-[0.22em] text-brass ${className}`}
    >
      {children}
    </p>
  );
}
