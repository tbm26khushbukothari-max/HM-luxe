import { ButtonHTMLAttributes, ReactNode } from "react";

export default function GhostButton({
  children,
  className = "",
  variant = "ghost",
  ...rest
}: {
  children: ReactNode;
  className?: string;
  variant?: "ghost" | "solid" | "sage";
} & ButtonHTMLAttributes<HTMLButtonElement>) {
  const base =
    "inline-flex items-center justify-center rounded-[12px] px-5 py-3 font-body text-[13px] font-semibold transition-transform duration-150 active:scale-[0.98] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brass";

  const variants: Record<string, string> = {
    ghost: "border border-[rgba(194,168,120,0.24)] text-brass bg-transparent",
    solid: "bg-brass text-bg",
    sage: "bg-sage text-bg",
  };

  return (
    <button className={`${base} ${variants[variant]} ${className}`} {...rest}>
      {children}
    </button>
  );
}
