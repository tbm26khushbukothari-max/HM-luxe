export default function Meter({
  pct,
  className = "",
  trackClassName = "bg-[rgba(239,233,220,0.11)]",
  fillClassName = "bg-brass",
}: {
  pct: number;
  className?: string;
  trackClassName?: string;
  fillClassName?: string;
}) {
  const clamped = Math.max(0, Math.min(100, pct));
  return (
    <div
      className={`h-[3px] w-full overflow-hidden rounded-full ${trackClassName} ${className}`}
      role="progressbar"
      aria-valuenow={clamped}
      aria-valuemin={0}
      aria-valuemax={100}
    >
      <div
        className={`h-full rounded-full ${fillClassName}`}
        style={{ width: `${clamped}%` }}
      />
    </div>
  );
}
