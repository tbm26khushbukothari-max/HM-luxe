import { HTMLAttributes, ReactNode } from "react";

export default function Card({
  children,
  className = "",
  ...rest
}: {
  children: ReactNode;
  className?: string;
} & HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={`rounded-card border border-[rgba(239,233,220,0.11)] bg-panel p-5 ${className}`}
      {...rest}
    >
      {children}
    </div>
  );
}
