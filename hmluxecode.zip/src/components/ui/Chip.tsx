export default function Chip({
  children,
  dot,
}: {
  children: React.ReactNode;
  dot?: "sage" | "clay" | "brass";
}) {
  const dotColor =
    dot === "sage" ? "bg-sage" : dot === "clay" ? "bg-clay" : dot === "brass" ? "bg-brass" : undefined;

  return (
    <span className="inline-flex items-center gap-1.5 rounded-full border border-[rgba(239,233,220,0.11)] bg-panel2 px-3 py-1 font-body text-[12px] text-body">
      {dotColor && <span className={`h-[6px] w-[6px] rounded-full ${dotColor}`} aria-hidden="true" />}
      {children}
    </span>
  );
}
