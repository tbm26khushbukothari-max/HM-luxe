"use client";

import { X } from "lucide-react";
import { ReactNode, useEffect, useRef } from "react";

export default function Sheet({
  open,
  onClose,
  title,
  children,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
}) {
  const panelRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="absolute inset-0 z-30">
      <button
        type="button"
        aria-label="Close sheet"
        onClick={onClose}
        className="absolute inset-0 h-full w-full animate-scrimIn bg-black/55"
      />
      <div
        ref={panelRef}
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className="absolute inset-x-0 bottom-0 max-h-[86%] animate-sheetUp overflow-y-auto rounded-t-[24px] border-t border-[rgba(239,233,220,0.11)] bg-panel px-5 pb-8 pt-3"
      >
        <div className="mx-auto mb-4 h-1 w-9 rounded-full bg-[rgba(239,233,220,0.18)]" aria-hidden="true" />
        <div className="mb-5 flex items-start justify-between">
          <h2 className="font-display text-[22px] font-semibold text-ink">{title}</h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="rounded-full p-1.5 text-muted focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brass"
          >
            <X size={20} strokeWidth={1.4} />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}
