"use client";

import { ReactNode, useEffect } from "react";

export default function Modal({
  open,
  onClose,
  label,
  children,
}: {
  open: boolean;
  onClose: () => void;
  label: string;
  children: ReactNode;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center p-6">
      <button
        type="button"
        aria-label="Close dialog"
        onClick={onClose}
        className="absolute inset-0 h-full w-full animate-scrimIn bg-black/60"
      />
      <div
        role="dialog"
        aria-modal="true"
        aria-label={label}
        className="relative w-full animate-modalIn rounded-card border border-[rgba(194,168,120,0.24)] bg-panel p-6"
      >
        {children}
      </div>
    </div>
  );
}
