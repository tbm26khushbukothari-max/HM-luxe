import PhoneShell from "@/components/PhoneShell";

export default function Page() {
  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-[#0b1310] p-0 min-[480px]:p-8">
      <PhoneShell />
    </div>
  );
}
