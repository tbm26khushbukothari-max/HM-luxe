import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/app/**/*.{ts,tsx}",
    "./src/components/**/*.{ts,tsx}",
    "./src/lib/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        bg: "#12201b",
        panel: "#1a2c24",
        panel2: "#22382d",
        ink: "#efe9dc",
        body: "#d7d1c3",
        muted: "#9aa79c",
        brass: "#c2a878",
        brassDeep: "#a2895f",
        sage: "#8fb79a",
        clay: "#c98f6b",
      },
      fontFamily: {
        display: ["var(--font-display)", "serif"],
        body: ["var(--font-body)", "sans-serif"],
      },
      borderRadius: {
        card: "20px",
        phone: "46px",
      },
      keyframes: {
        riseIn: {
          "0%": { opacity: "0", transform: "translateY(10px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        sheetUp: {
          "0%": { transform: "translateY(100%)" },
          "100%": { transform: "translateY(0)" },
        },
        scrimIn: {
          "0%": { opacity: "0" },
          "100%": { opacity: "1" },
        },
        modalIn: {
          "0%": { opacity: "0", transform: "translateY(8px) scale(0.98)" },
          "100%": { opacity: "1", transform: "translateY(0) scale(1)" },
        },
      },
      animation: {
        riseIn: "riseIn 420ms ease both",
        sheetUp: "sheetUp 380ms cubic-bezier(0.22,1,0.36,1) both",
        scrimIn: "scrimIn 300ms ease both",
        modalIn: "modalIn 320ms ease both",
      },
    },
  },
  plugins: [],
};

export default config;
